# Agent Team

A multi-agent orchestration framework that runs a team of specialized [Claude Code](https://docs.anthropic.com/en/docs/claude-code) agents against any codebase. Each agent has a focused role -- code reviewer, security analyst, feature architect, GitHub ops manager -- and produces a structured markdown report. A manager agent consolidates everything into a prioritized implementation plan.

The system can also **assess its own gaps** and propose new agents via a self-evolution workflow.

## Quick Start

```powershell
# 1. Clone into your project as .agent/
git clone https://github.com/dalwaut/agent-team.git .agent

# 2. See available squads
.\.agent\scripts\run_squad.ps1 -List

# 3. Run a full codebase audit
.\.agent\scripts\run_squad.ps1 -Squad "audit"

# 4. Read the reports
ls .\.agent\reports\latest\
```

Or use the setup script to install into any project:

```powershell
git clone https://github.com/dalwaut/agent-team.git agent-team-src
.\agent-team-src\setup.ps1 -Target "C:\path\to\your\project"
```

## Requirements

- [Claude Code CLI](https://docs.anthropic.com/en/docs/claude-code) installed and authenticated (`claude` in PATH)
- PowerShell 5.1+ (Windows) or PowerShell 7+ (cross-platform)
- Git (for the GitHub agent)
- `gh` CLI (optional, for GitHub operations)

## Architecture

```
.agent/
├── team.json                    # Agent roster + squad definitions
├── scripts/
│   ├── preflight.ps1            # Environment validation
│   ├── run_squad.ps1            # Run a named squad from team.json
│   ├── run_agents.ps1           # Run all agents in parallel
│   ├── run_agents_seq.ps1       # Run all agents sequentially
│   └── prompt_*.txt             # One prompt file per agent role
├── workflows/
│   ├── delegate-analysis.md     # Main workflow documentation
│   ├── self-evolution.md        # How the system improves itself
│   └── portability.md           # How to adapt for different projects
├── templates/
│   └── prompt_*.txt             # Project-specific specialist templates
└── reports/
    ├── <date>/                  # Timestamped report directories
    └── latest/                  # Most recent run
```

## The Team

### Universal Agents (work in any codebase)

| Agent | Role | What It Analyzes |
|-------|------|-----------------|
| `manager` | Project Manager | Reads all reports, builds prioritized implementation plan |
| `reviewer` | Code Reviewer | Quality, consistency, error handling, type safety |
| `accuracy` | Accuracy Auditor | Calculations, data transformations, date/time logic |
| `health` | Health Auditor | Performance, dead code, unused deps, bundle size |
| `security` | Security Analyst | OWASP audit, auth, secrets, injection vectors |
| `features` | Feature Architect | Architecture plans for new features |
| `integration` | Integration Architect | Cross-project and third-party integration blueprints |
| `researcher` | Tech Researcher | Dependency health, tech radar, best practices |
| `github` | GitHub Ops Manager | Versioning, PRs, issues, releases, CI/CD, repo hygiene |
| `content_curator` | Content Curator | Changelogs, app store copy, social posts, SEO |
| `test_writer` | Test Engineer | Coverage gaps, test specs, scaffolding |
| `ux_reviewer` | UX Reviewer | Loading/error/empty states, accessibility, consistency |
| `self_assessment` | Meta-Agent | **Detects gaps in the team and proposes new agents** |

### Specialist Templates (adapt per project)

Found in `templates/`. Copy into `scripts/` and customize:

| Template | For Projects Using |
|----------|-------------------|
| `prompt_expo_expert.txt` | Expo / React Native |
| `prompt_supabase_expert.txt` | Supabase |
| `prompt_n8n_connector.txt` | n8n automation |

## Squads

| Squad | Agents | Use Case |
|-------|--------|----------|
| `audit` | accuracy, health, security, ux_reviewer, manager | Full codebase health check |
| `plan` | features, integration, researcher, manager | Planning new features |
| `review` | reviewer, accuracy, test_writer, github, manager | After code changes |
| `ship` | health, security, test_writer, content_curator, github, manager | Pre-release checks |
| `release` | github, content_curator, test_writer, security, manager | Version bump + publish |
| `evolve` | self_assessment | System self-improvement |

## Usage

```powershell
# List squads
.\.agent\scripts\run_squad.ps1 -List

# Run a squad
.\.agent\scripts\run_squad.ps1 -Squad "audit"

# Run specific agents
.\.agent\scripts\run_agents_seq.ps1 -Filter "accuracy,health"

# Force re-run
.\.agent\scripts\run_squad.ps1 -Squad "audit" -Force

# Limit concurrency
.\.agent\scripts\run_squad.ps1 -Squad "audit" -MaxParallel 2
```

## Self-Evolution

```powershell
.\.agent\scripts\run_squad.ps1 -Squad "evolve"
```

The `self_assessment` meta-agent reads the entire framework and outputs:
- Coverage gap analysis
- Prompt quality scores
- Complete new agent specs with ready-to-use prompt text
- Workflow improvement suggestions

**A human must review and approve** before changes are applied. See [self-evolution.md](workflows/self-evolution.md).

## How It Works

1. Prompts are piped via temp files (not CLI args) to avoid shell quoting issues
2. Reports are UTF-8 no BOM via .NET `UTF8Encoding($false)`
3. Parallel agents run first, then `run_order: "last"` agents that need prior reports
4. Reports are timestamped (`reports/2026-02-09/`) with a `latest/` symlink
5. All agents are read-only -- `claude -p` pipe mode, stdout only

## Adding a Specialist

```powershell
# 1. Copy a template
cp .agent\templates\prompt_expo_expert.txt .agent\scripts\prompt_expo_expert.txt

# 2. Edit to match your project

# 3. Add to team.json roles + squads

# 4. Test
.\.agent\scripts\run_agents_seq.ps1 -Filter "expo_expert"
```

## License

MIT
